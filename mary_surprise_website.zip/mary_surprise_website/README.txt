FOR MARY — A LITTLE SURPRISE FROM ASA REST 💗

Open index.html in a web browser to try the website on your computer.
The website is made for phones and computers.

To give Mary a public link:
  1. Extract this ZIP to a folder.
  2. From that folder open a terminal.
  3. Run: npx vercel --prod
  4. Follow Vercel's setup questions and share the final URL with Mary.

Keep the "assets" folder next to index.html.
- assets/gift-song.m4a is extracted audio from "Thank you baby.mp4".
- assets/final-surprise.mp4 is your WhatsApp surprise video.

Everything runs in the browser; Mary's answers are not uploaded or saved.
The audio starts when she taps her gift. If her browser blocks sound,
there is a Play button she can tap.
